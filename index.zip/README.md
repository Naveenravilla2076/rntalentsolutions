# RN Talent Solutions Website

Open `index.html` in a browser to preview the responsive website.

## Included
- RN Talent Solutions logo
- CEO photo: Ravilla Naveen Naidu
- US-focused IT staffing and talent marketing positioning
- Client and candidate service sections
- Responsive desktop/tablet/mobile design
- Contact email and phone CTA
- No candidate-fee/pricing terms published on the public website

## Contact currently shown
Email: rntalentsolutions@gmail.com
Direct line: +91 7670978017

Before publishing, replace/add:
- Official US business address (if applicable)
- Business registration/legal details
- Privacy Policy
- Terms of Use
- LinkedIn/company social links
- Any verified US phone number or domain email
- Final service/pricing disclosures approved by your business/legal advisor
